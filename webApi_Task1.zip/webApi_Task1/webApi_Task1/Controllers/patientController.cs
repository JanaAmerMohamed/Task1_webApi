﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using webApi_Task1.Models;

namespace webApi_Task1.Controllers
{
    public class patientController : ApiController
    {

        List<patient> patients = new List<patient>() { new patient()
        {
            id=5 , name="Amr"
        },
            new patient()
        {
            id=2 , name="khaled"
        },
        };
        /// <summary>
        /// GetALLPatients this method returns all patients
        /// </summary>
        /// <returns>
        /// list patients
        /// </returns>
        [HttpGet]
        public List<patient> GetALLPatients() {
            return patients;
        }

        public IHttpActionResult GetPatients(int id) {
            var patient = patients.Where(x => x.id == id).FirstOrDefault();
            if (patient == null)
            {
                return BadRequest();
            }
            else
            {
                return Ok( patient);
            }
                
        }
        [HttpPost]
        public IHttpActionResult postpatient([FromBody] patient patient) {
            if (ModelState.IsValid)
            {
                if (patients.Any(x => x.id == patient.id))
                {
                    return Conflict();
                }
                else
                {
                    patients.Add(patient);
                    return Ok(patient);
                }
            }
            else
            {
                return BadRequest("Patient is not valid !");
            }
        }



    }
}
