﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace webApi_Task1.Models
{
    public class patient
    {
        public int id { get; set; }

        [Required]

        public string name { get; set; }
    }
}